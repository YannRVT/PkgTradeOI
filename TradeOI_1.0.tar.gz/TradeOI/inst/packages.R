if(!require(shiny)){install.packages("shiny")}
if(!require(shinydashboard)){install.packages("shinydashboard")}
if(!require(shinycssloaders)){install.packages("shinycssloaders")}
if(!require(shinyjs)){install.packages("shinyjs")}
if(!require(shinyalert)){install.packages("shinyalert")}

if(!require(filehash)){install.packages("filehash")}
if(!require(sqldf)){install.packages("sqldf")}
if(!require(stringr)){install.packages("stringr")}
if(!require(data.table)){install.packages("data.table")}
if(!require(robustbase)){install.packages("robustbase")}
if(!require(doParallel)){install.packages("doParallel")}
if(!require(gsubfn)){install.packages("gsubfn")}
if(!require(proto)){install.packages("proto")}
if(!require(RSQLite)){install.packages("RSQLite")}
if(!require(foreach)){install.packages("foreach")}
if(!require(iterators)){install.packages("iterators")}
if(!require(dplyr)){install.packages("dplyr")}
if(!require(optiRum)){install.packages("optiRum")}
if(!require(compiler)){install.packages("compiler")}
if(!require(DT)){install.packages("DT")}
if(!require(stringi)){install.packages("stringi")}
if(!require(highcharter)){install.packages("highcharter")}
if(!require(parallel)){install.packages("parallel")}

