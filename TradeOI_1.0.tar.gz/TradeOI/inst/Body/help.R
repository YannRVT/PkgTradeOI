tabItem(tabName = "help",
        fluidPage(
          box(width = 12, status = "primary",
              shiny::includeMarkdown("inst/Text/help.Rmd"))
        )
)
